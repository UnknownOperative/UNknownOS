https://www.kismetwireless.net

To facilitate building the website docs, the README is now broken up into multiple files, which can be found in the `docs/readme/` directory.

The generated Kismet docs can be most easily found and read at [the Kismet website](https://www.kismetwireless.net/docs/readme/quickstart/)




Docs are now generated from a Git sub-repository at:

```bash
$ git clone https://www.kismetwireless.net/git/kismet-docs.git
```

and mirrored on Github at:

```bash
$ git clone https://www.github.com/kismetwireless/kismet-docs
```

